package com.example.lecturenotes

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File

data class Line(val text: String, val dictation: Boolean)

/** Общее хранилище текста + состояние. Текст дублируется в файл, чтобы лекция не потерялась. */
object Store {
    private val lines = ArrayList<Line>()
    private val main = Handler(Looper.getMainLooper())
    private var file: File? = null

    /** 0 = ничего не делаем, 1 = идёт запись, 2 = дорабатываем очередь */
    @Volatile var state = 0
    @Volatile var status = "Готов"
    @Volatile var listener: (() -> Unit)? = null

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.applicationContext.filesDir, "transcript.txt")
        file = f
        if (f.exists()) {
            f.forEachLine { ln ->
                val p = ln.split('\t', limit = 2)
                if (p.size == 2) lines.add(Line(p[1], p[0] == "D"))
            }
        }
    }

    @Synchronized
    fun add(l: Line) {
        lines.add(l)
        try {
            val mark = if (l.dictation) "D" else "N"
            file?.appendText(mark + "\t" + l.text.replace('\t', ' ').replace('\n', ' ') + "\n")
        } catch (_: Exception) {
        }
        changed()
    }

    @Synchronized
    fun snapshot(): List<Line> = ArrayList(lines)

    @Synchronized
    fun clear() {
        lines.clear()
        try {
            file?.delete()
        } catch (_: Exception) {
        }
        changed()
    }

    fun setState(s: Int, st: String) {
        state = s
        status = st
        changed()
    }

    fun setStatus(st: String) {
        status = st
        changed()
    }

    private fun changed() {
        main.post { listener?.invoke() }
    }
}
