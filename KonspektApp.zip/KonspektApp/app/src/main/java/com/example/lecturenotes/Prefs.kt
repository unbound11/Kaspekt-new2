package com.example.lecturenotes

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun key(c: Context): String = sp(c).getString("groq_key", "") ?: ""

    fun setKey(c: Context, k: String) {
        sp(c).edit().putString("groq_key", k.trim()).apply()
    }
}
