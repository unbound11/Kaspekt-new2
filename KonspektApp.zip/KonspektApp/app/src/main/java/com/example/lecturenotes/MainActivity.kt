package com.example.lecturenotes

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var tvStatus: TextView
    private lateinit var tvText: TextView
    private lateinit var svText: ScrollView
    private lateinit var btnRec: Button
    private lateinit var btnMode: Button

    private var onlyDict = false
    private var plain = ""

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasMic()) startRec() else toast("Без доступа к микрофону не получится")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Store.init(this)

        tvStatus = findViewById(R.id.tvStatus)
        tvText = findViewById(R.id.tvText)
        svText = findViewById(R.id.svText)
        btnRec = findViewById(R.id.btnRec)
        btnMode = findViewById(R.id.btnMode)

        btnRec.setOnClickListener {
            when (Store.state) {
                0 -> {
                    if (Prefs.key(this).isEmpty()) showKeyDialog { tryStart() } else tryStart()
                }
                1 -> startService(
                    Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP)
                )
            }
        }

        btnMode.setOnClickListener {
            onlyDict = !onlyDict
            render()
        }

        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("konspekt", plain))
            toast("Скопировано")
        }

        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, plain)
            startActivity(Intent.createChooser(i, "Поделиться текстом"))
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (Store.state != 0) {
                toast("Сначала останови запись")
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setMessage("Удалить весь текст?")
                .setPositiveButton("Удалить") { _, _ -> Store.clear() }
                .setNegativeButton("Отмена", null)
                .show()
        }

        findViewById<Button>(R.id.btnKey).setOnClickListener { showKeyDialog(null) }
    }

    override fun onStart() {
        super.onStart()
        Store.listener = { render() }
        render()
    }

    override fun onStop() {
        Store.listener = null
        super.onStop()
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun tryStart() {
        val need = ArrayList<String>()
        if (!hasMic()) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)

        if (need.isEmpty()) startRec() else permLauncher.launch(need.toTypedArray())
    }

    private fun startRec() {
        ContextCompat.startForegroundService(
            this, Intent(this, RecordService::class.java).setAction(RecordService.ACTION_START)
        )
    }

    private fun showKeyDialog(onSaved: (() -> Unit)?) {
        val et = EditText(this)
        et.hint = "gsk_..."
        et.setSingleLine()
        et.setText(Prefs.key(this))
        AlertDialog.Builder(this)
            .setTitle("Ключ Groq (бесплатный)")
            .setMessage("Открой console.groq.com → API Keys → Create API Key и вставь ключ сюда. Он хранится только на телефоне.")
            .setView(et)
            .setPositiveButton("Сохранить") { _, _ ->
                Prefs.setKey(this, et.text.toString())
                onSaved?.invoke()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Склеиваем подряд идущие фразы одного типа в абзацы. */
    private fun blocks(): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        for (l in Store.snapshot()) {
            val last = out.lastOrNull()
            if (last != null && last.first == l.dictation) {
                out[out.size - 1] = Pair(last.first, last.second + " " + l.text)
            } else {
                out.add(Pair(l.dictation, l.text))
            }
        }
        return out
    }

    private fun render() {
        val bl = blocks().filter { !onlyDict || it.first }
        val sb = SpannableStringBuilder()
        for ((d, t) in bl) {
            if (sb.isNotEmpty()) sb.append("\n\n")
            val s = sb.length
            sb.append(if (d) "✎ $t" else t)
            if (d) {
                sb.setSpan(BackgroundColorSpan(Color.parseColor("#FFF3C4")), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        plain = sb.toString()
        tvText.text = if (bl.isEmpty()) {
            if (onlyDict) "Диктовки пока нет." else "Нажми «Записать» — текст появится здесь.\n\nЖёлтым выделяется то, что препод диктует."
        } else sb

        tvStatus.text = Store.status
        btnMode.text = if (onlyDict) "Только диктовка" else "Всё"
        btnRec.text = when (Store.state) {
            0 -> "●  Записать"
            1 -> "■  Стоп"
            else -> "Дорабатываю…"
        }
        btnRec.isEnabled = Store.state != 2
        btnRec.backgroundTintList = ColorStateList.valueOf(
            Color.parseColor(if (Store.state == 1) "#C62828" else "#2E7D32")
        )
        if (Store.state == 1) svText.post { svText.fullScroll(View.FOCUS_DOWN) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
