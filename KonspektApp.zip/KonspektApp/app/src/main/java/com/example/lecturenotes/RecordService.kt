package com.example.lecturenotes

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.sqrt

/**
 * Пишет звук с микрофона, режет на куски по паузам (20–35 сек),
 * отправляет куски на распознавание и складывает текст в Store.
 * Работает как foreground-сервис — не умирает при выключенном экране.
 */
class RecordService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CH = "rec"
        private const val SR = 16000
        private const val SILENCE_RMS = 300.0  // тише — считаем паузой
        private const val MIN_RMS = 150.0      // кусок тише — вообще не отправляем
        private const val SOFT_CUT = 20.0      // с этой секунды режем на ближайшей паузе
        private const val HARD_CUT = 35.0      // режем принудительно
        private val BAD = listOf(
            "субтитры", "dimatorzok", "продолжение следует",
            "спасибо за просмотр", "редактор субтитров", "подписывайтесь"
        )
    }

    private class Chunk(val pcm: ByteArray, val offset: Double, val last: Boolean)

    private val queue = LinkedBlockingQueue<Chunk>()
    @Volatile private var running = false
    private var wake: PowerManager.WakeLock? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start()
            ACTION_STOP -> {
                if (running) {
                    running = false
                    Store.setState(2, "Дорабатываю последние фразы…")
                } else {
                    stopSelf()
                }
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start() {
        // startForeground нужно вызвать всегда сразу после startForegroundService
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Запись лекции", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, CH)
            .setContentTitle("Конспект")
            .setContentText("Идёт запись лекции")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, 1, n, type)

        if (running || Store.state == 2) return
        val key = Prefs.key(this)
        if (key.isEmpty()) {
            Store.setState(0, "Сначала вставь ключ (кнопка «Ключ»)")
            finish()
            return
        }

        Store.init(this)
        running = true
        queue.clear()
        Store.setState(1, "Слушаю…")

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "konspekt:rec").also { it.acquire(4 * 60 * 60 * 1000L) }

        Thread { recordLoop() }.start()
        Thread { workLoop(key) }.start()
    }

    private fun finish() {
        main.post {
            try {
                wake?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    // ---------------- запись ----------------

    private fun recordLoop() {
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val frame = SR / 10 // 100 мс
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, frame * 8)
            )
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            running = false
            Store.updateStatus("Не удалось включить микрофон")
            queue.put(Chunk(ByteArray(0), 0.0, true))
            return
        }

        val buf = ShortArray(frame)
        val bytes = ByteArray(frame * 2)
        var out = ByteArrayOutputStream()
        var samples = 0
        var silent = 0
        var maxRms = 0.0
        var offset = 0.0

        rec.startRecording()
        while (running) {
            val n = rec.read(buf, 0, frame)
            if (n < 0) break
            if (n == 0) continue
            var sum = 0.0
            for (i in 0 until n) {
                val v = buf[i].toInt()
                sum += (v * v).toDouble()
                bytes[2 * i] = (v and 0xff).toByte()
                bytes[2 * i + 1] = (v shr 8).toByte()
            }
            out.write(bytes, 0, n * 2)
            val rms = sqrt(sum / n)
            if (rms > maxRms) maxRms = rms
            silent = if (rms < SILENCE_RMS) silent + n else 0
            samples += n
            val secs = samples / SR.toDouble()
            if ((secs >= SOFT_CUT && silent >= SR / 2) || secs >= HARD_CUT) {
                if (maxRms >= MIN_RMS) queue.put(Chunk(out.toByteArray(), offset, false))
                offset += secs
                out = ByteArrayOutputStream()
                samples = 0
                silent = 0
                maxRms = 0.0
            }
        }
        try {
            rec.stop()
        } catch (_: Exception) {
        }
        rec.release()

        if (samples >= SR && maxRms >= MIN_RMS) queue.put(Chunk(out.toByteArray(), offset, false))
        running = false
        queue.put(Chunk(ByteArray(0), 0.0, true))
    }

    // ---------------- распознавание ----------------

    private fun workLoop(key: String) {
        val det = DictationDetector()
        var tail = ""
        var err: String? = null
        var authFailed = false

        while (true) {
            val c = try {
                queue.take()
            } catch (e: InterruptedException) {
                break
            }
            if (c.last) break
            if (authFailed) continue

            if (Store.state == 1) Store.updateStatus("Слушаю… (в очереди: ${queue.size + 1})")
            var attempt = 0
            while (true) {
                try {
                    val json = Groq.transcribe(key, wav(c.pcm), tail)
                    tail = handle(json, c.offset, det, tail)
                    break
                } catch (e: Groq.ApiException) {
                    if (e.code == 401) {
                        err = "Ключ не подошёл. Нажми «Ключ» и вставь заново."
                        authFailed = true
                        running = false
                        break
                    }
                    attempt++
                    if (attempt >= 5) {
                        Store.updateStatus("Кусок пропущен (ошибка ${e.code})")
                        break
                    }
                    Thread.sleep(4000L * attempt)
                } catch (e: IOException) {
                    attempt++
                    if (attempt >= 6) {
                        Store.updateStatus("Нет сети — кусок пропущен")
                        break
                    }
                    Store.updateStatus("Нет сети, пробую снова…")
                    Thread.sleep(4000L * attempt)
                } catch (e: Exception) {
                    break
                }
            }
            if (Store.state == 1) Store.updateStatus("Слушаю…")
        }

        running = false
        Store.setState(0, err ?: "Готово")
        finish()
    }

    private fun handle(json: JSONObject, offset: Double, det: DictationDetector, tailIn: String): String {
        var tail = tailIn
        val segs = json.optJSONArray("segments") ?: return tail
        for (i in 0 until segs.length()) {
            val s = segs.getJSONObject(i)
            val text = s.optString("text").trim()
            if (text.isEmpty()) continue
            if (s.optDouble("no_speech_prob", 0.0) > 0.6 && s.optDouble("avg_logprob", 0.0) < -0.8) continue
            if (s.optDouble("compression_ratio", 1.0) > 2.4) continue
            val low = text.lowercase()
            if (BAD.any { low.contains(it) }) continue

            val st = offset + s.optDouble("start", 0.0)
            val en = offset + s.optDouble("end", 0.0)
            val d = det.classify(text, st, en)
            Store.add(Line(text, d))
            tail = (tail + " " + text).takeLast(200)
        }
        return tail
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1)
        bb.putShort(1)
        bb.putInt(SR)
        bb.putInt(SR * 2)
        bb.putShort(2)
        bb.putShort(16)
        bb.put("data".toByteArray())
        bb.putInt(pcm.size)
        bb.put(pcm)
        return bb.array()
    }
}
