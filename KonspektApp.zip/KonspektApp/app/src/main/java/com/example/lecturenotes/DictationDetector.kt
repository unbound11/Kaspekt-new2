package com.example.lecturenotes

/**
 * Определяет, что препод сейчас ДИКТУЕТ (а не просто объясняет).
 * Признаки:
 *  1) слова-триггеры: «пишите», «запишите», «записываем»… — после них включается режим диктовки;
 *  2) медленная речь: мало слов в секунду (обычная речь ~2.5–3 сл/с, диктовка ~1–1.5 сл/с);
 *  3) режим выключается, когда препод снова начинает говорить быстро (2 быстрые фразы подряд).
 * Пороги можно подкрутить в константах ниже.
 */
class DictationDetector {
    companion object {
        const val SLOW_WPS = 1.7      // медленнее — считаем диктовкой
        const val FAST_WPS = 2.6      // быстрее — обычная речь
        const val ARMED_MAX_SEC = 90.0 // максимум, сколько держим режим после триггера
    }

    private val trigger = Regex(
        "пишите|запишите|записывайте|записываем|записываю|продиктую|диктую|диктуем|" +
            "под запись|для записи|запишем|пишем|в тетрадь|в тетради|в конспект",
        RegexOption.IGNORE_CASE
    )

    private var armed = false
    private var armedAt = 0.0
    private var fastStreak = 0
    private var slowStreak = 0

    fun classify(text: String, start: Double, end: Double): Boolean {
        val words = text.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
        val dur = maxOf(end - start, 0.5)
        val wps = words / dur

        val hasTrigger = trigger.containsMatchIn(text)
        val fast = wps > FAST_WPS && words >= 6
        val slow = wps < SLOW_WPS && words >= 3

        if (hasTrigger) {
            armed = true
            armedAt = start
            fastStreak = 0
        } else {
            fastStreak = if (fast) fastStreak + 1 else 0
            if (armed && (fastStreak >= 2 || start - armedAt > ARMED_MAX_SEC)) armed = false
        }
        slowStreak = if (slow) slowStreak + 1 else 0

        return hasTrigger || (armed && !fast) || slowStreak >= 2
    }
}
